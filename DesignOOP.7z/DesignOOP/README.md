# Esse reposiório descreve 3 ténicas dentro de POO

# Herança

- Estudar o código e fazer uma breve descriação do que entendeu

# Composição / Associação

- Estudar o código e fazer uma breve descriação do que entendeu

# Injeção de Dependencia

- Estudar o código e fazer uma breve descriação do que entendeu