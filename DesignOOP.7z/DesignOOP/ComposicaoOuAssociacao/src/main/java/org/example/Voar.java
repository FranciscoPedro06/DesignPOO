package org.example;

public class Voar {
    public void voar(String animal) {
        System.out.println("Esse método faz voar: " + animal);
    }
}
