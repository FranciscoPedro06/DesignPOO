package org.example;

public class Nadar {
    public void nadar() {
        System.out.println("Esse método faz nadar");
    }
}
