package org.example;

public class EmitirSom {
    public void emitirSom(String som) {
        System.out.println("O animal faz: " + som);
    }
}
