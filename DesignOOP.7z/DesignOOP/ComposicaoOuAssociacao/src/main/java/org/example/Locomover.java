package org.example;

public class Locomover {
    public void locomover() {
        System.out.println("Esse método faz locomover");
    }
}
