package org.example;

public class Respirar {
    public void respirar() {
        System.out.println("Esse método faz respirar");
    }
}
