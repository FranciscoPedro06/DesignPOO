package org.example;

public class Dormir {
    public Dormir() {
    }

    public void dormir(String animal) {
        System.out.println("Esse método faz dormir: " + animal);
    }
}
