package org.example;

public class Cavalo extends Animal {
    public Cavalo(String nome, String raca, String cor, int idade) {
        super(nome, raca, cor, idade);
    }

}
