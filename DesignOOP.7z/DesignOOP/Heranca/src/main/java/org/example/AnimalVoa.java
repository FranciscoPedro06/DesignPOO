package org.example;

public class AnimalVoa extends Animal {
    public AnimalVoa(String nome, String raca, String cor, int idade) {
        super(nome, raca, cor, idade);
    }
}
