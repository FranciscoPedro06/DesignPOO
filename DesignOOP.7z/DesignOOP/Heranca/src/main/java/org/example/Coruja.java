package org.example;

public class Coruja extends Animal {
    public Coruja(String nome, String raca, String cor, int idade) {
        super(nome, raca, cor, idade);
    }

    @Override
    public void comer() {
        super.comer();
    }

    @Override
    public void dormir() {
        super.dormir();
    }

    @Override
    public void fazerSom() {
        super.fazerSom();
    }

    @Override
    public void locomover() {
        super.locomover();
    }
}
